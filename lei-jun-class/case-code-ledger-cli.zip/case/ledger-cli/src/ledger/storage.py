import csv
from pathlib import Path

from .models import Entry
from .parser import parse_line


def load_csv(path: str | Path) -> list[Entry]:
    entries = []
    with open(path, encoding="utf-8") as f:
        for i, line in enumerate(f):
            if i == 0 and line.startswith("日期"):
                continue
            if line.strip():
                entries.append(parse_line(line))
    return entries


def save_csv(path: str | Path, entries: list[Entry]) -> None:
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["日期", "金额", "分类", "备注"])
        for e in entries:
            w.writerow([e.day.isoformat(), str(e.amount), e.category, e.note])
