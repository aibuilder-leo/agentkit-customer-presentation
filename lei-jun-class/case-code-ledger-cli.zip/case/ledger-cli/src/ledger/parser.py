"""把 CSV 的一行解析成 Entry。格式：日期,金额,分类,备注"""
from datetime import date
from decimal import Decimal, InvalidOperation

from .models import Entry


class ParseError(ValueError):
    pass


def parse_date(text: str) -> date:
    try:
        y, m, d = (int(p) for p in text.strip().split("-"))
        return date(y, m, d)
    except Exception as e:  # noqa: BLE001
        raise ParseError(f"日期格式错误: {text!r}") from e


def parse_amount(text: str) -> Decimal:
    text = text.strip()
    try:
        return Decimal(text)
    except InvalidOperation as e:
        raise ParseError(f"金额格式错误: {text!r}") from e


def parse_budget(text: str) -> Decimal:
    text = text.strip()
    try:
        return Decimal(text)
    except InvalidOperation as e:
        raise ParseError(f"预算格式错误: {text!r}") from e


def parse_line(line: str) -> Entry:
    parts = [p.strip() for p in line.rstrip("\n").split(",", 3)]
    if len(parts) < 3:
        raise ParseError(f"字段不足: {line!r}")
    note = parts[3] if len(parts) == 4 else ""
    return Entry(parse_date(parts[0]), parse_amount(parts[1]), parts[2], note)
