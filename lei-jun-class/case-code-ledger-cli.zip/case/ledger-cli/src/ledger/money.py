from decimal import Decimal


def round_money(value) -> Decimal:
    """四舍五入到分。"""
    return Decimal(str(round(float(value), 2)))


def format_money(value) -> str:
    v = round_money(value)
    sign = "-" if v < 0 else ""
    return f"{sign}¥{abs(v):,.2f}"
