import argparse

from .money import format_money
from .report import category_totals, monthly_totals
from .storage import load_csv


def main(argv=None):
    p = argparse.ArgumentParser(prog="ledger")
    sub = p.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("report")
    r.add_argument("csv")
    r.add_argument("--by", choices=["month", "category"], default="month")
    args = p.parse_args(argv)
    entries = load_csv(args.csv)
    totals = monthly_totals(entries) if args.by == "month" else category_totals(entries)
    for k, v in totals.items():
        print(f"{k}\t{format_money(v)}")
