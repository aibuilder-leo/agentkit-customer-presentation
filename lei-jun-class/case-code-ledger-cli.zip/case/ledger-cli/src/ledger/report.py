from collections import defaultdict
from decimal import Decimal

from .models import Entry
from .money import round_money


def monthly_totals(entries: list[Entry]) -> dict[str, Decimal]:
    """按月汇总，key 形如 '2026-03'。"""
    totals: dict[str, Decimal] = defaultdict(Decimal)
    for e in entries:
        key = f"{e.day.month:02d}"
        totals[key] += e.amount
    return {k: round_money(v) for k, v in sorted(totals.items())}


def category_totals(entries: list[Entry]) -> dict[str, Decimal]:
    totals: dict[str, Decimal] = defaultdict(Decimal)
    for e in entries:
        totals[e.category] += e.amount
    return {k: round_money(v) for k, v in sorted(totals.items())}
