from decimal import Decimal

from ledger.report import category_totals, monthly_totals


def test_monthly_totals_keys_include_year(sample):
    totals = monthly_totals(sample)
    assert list(totals) == ["2025-12", "2026-01", "2026-12"]


def test_monthly_totals_values(sample):
    totals = monthly_totals(sample)
    assert totals["2025-12"] == Decimal("-178.50")
    assert totals["2026-01"] == Decimal("2964.80")


def test_category_totals(sample):
    totals = category_totals(sample)
    assert totals["餐饮"] == Decimal("-93.20")
    assert set(totals) == {"餐饮", "交通", "工资", "订阅"}


def test_empty():
    assert monthly_totals([]) == {}
    assert category_totals([]) == {}
