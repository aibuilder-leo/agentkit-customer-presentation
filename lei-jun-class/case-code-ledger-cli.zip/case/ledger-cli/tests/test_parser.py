from datetime import date
from decimal import Decimal

import pytest

from ledger.parser import ParseError, parse_amount, parse_date, parse_line


@pytest.mark.parametrize("text,expected", [
    ("12.50", Decimal("12.50")),
    ("-8", Decimal("-8")),
    (" 0.01 ", Decimal("0.01")),
    ("1,234.50", Decimal("1234.50")),
])
def test_parse_amount(text, expected):
    assert parse_amount(text) == expected


def test_parse_amount_invalid():
    with pytest.raises(ParseError):
        parse_amount("abc")


def test_parse_date():
    assert parse_date("2026-03-07") == date(2026, 3, 7)


@pytest.mark.parametrize("bad", ["2026/03/07", "2026-13-01", ""])
def test_parse_date_invalid(bad):
    with pytest.raises(ParseError):
        parse_date(bad)


def test_parse_line_with_note():
    e = parse_line("2026-03-07,-25.00,餐饮,午饭, 和同事\n")
    assert e.note == "午饭, 和同事"
    assert e.category == "餐饮"


def test_parse_line_without_note():
    assert parse_line("2026-03-07,-25.00,餐饮").note == ""


def test_parse_line_too_short():
    with pytest.raises(ParseError):
        parse_line("2026-03-07,-25.00")
