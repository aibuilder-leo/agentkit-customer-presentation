from decimal import Decimal

import pytest

from ledger.money import format_money, round_money


@pytest.mark.parametrize("value,expected", [
    ("1.234", Decimal("1.23")),
    ("1.235", Decimal("1.24")),
    ("2.675", Decimal("2.68")),
    ("-0.005", Decimal("-0.01")),
    (10, Decimal("10.00")),
])
def test_round_money_half_up(value, expected):
    assert round_money(value) == expected


@pytest.mark.parametrize("value,expected", [
    ("1234.5", "¥1,234.50"),
    ("-58", "-¥58.00"),
    ("0", "¥0.00"),
])
def test_format_money(value, expected):
    assert format_money(value) == expected
