from datetime import date
from decimal import Decimal

import pytest

from ledger.models import Entry


@pytest.fixture
def sample():
    return [
        Entry(date(2025, 12, 3), Decimal("-58.00"), "餐饮"),
        Entry(date(2025, 12, 20), Decimal("-120.50"), "交通"),
        Entry(date(2026, 1, 5), Decimal("3000.00"), "工资"),
        Entry(date(2026, 1, 9), Decimal("-35.20"), "餐饮"),
        Entry(date(2026, 12, 1), Decimal("-99.00"), "订阅"),
    ]
