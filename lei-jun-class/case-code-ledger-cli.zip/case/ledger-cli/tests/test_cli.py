from ledger.cli import main
from ledger.storage import save_csv


def test_report_by_category(tmp_path, sample, capsys):
    p = tmp_path / "c.csv"
    save_csv(p, sample)
    main(["report", str(p), "--by", "category"])
    out = capsys.readouterr().out
    assert "餐饮\t-¥93.20" in out
