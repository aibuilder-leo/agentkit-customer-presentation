from ledger.storage import load_csv, save_csv


def test_roundtrip(tmp_path, sample):
    p = tmp_path / "a.csv"
    save_csv(p, sample)
    assert load_csv(p) == sample


def test_skip_header_and_blank(tmp_path):
    p = tmp_path / "b.csv"
    p.write_text("日期,金额,分类,备注\n\n2026-01-01,-1,杂项,\n", encoding="utf-8")
    assert len(load_csv(p)) == 1
