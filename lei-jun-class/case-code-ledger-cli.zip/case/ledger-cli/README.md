# ledger-cli

一个命令行记账小工具：从 CSV 导入流水，按月、按分类汇总。

    python -m ledger import data/2026.csv
    python -m ledger report --month 2026-03
