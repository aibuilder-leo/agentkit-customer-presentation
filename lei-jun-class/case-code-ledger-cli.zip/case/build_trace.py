"""按设计好的模型输出，真实执行工具，生成贯穿案例的标准 trace。
模型那一侧的输出是设计稿；工具结果全部是在仓库里真实执行得到的。
token 用 Qwen 分词表（tiktoken 加载）计数，不含 chat template 的特殊 token（课前用真实模型录制后替换）。
"""
import json, subprocess, shutil, pathlib, sys
import tiktoken

HERE = pathlib.Path(__file__).parent
SRC = HERE / "ledger-cli"
WORK = HERE / "_run"
if WORK.exists():
    shutil.rmtree(WORK)
shutil.copytree(SRC, WORK, ignore=shutil.ignore_patterns(".git", "__pycache__", ".pytest_cache"))
from tiktoken.load import load_tiktoken_bpe
PAT = r"""(?i:'s|'t|'re|'ve|'m|'ll|'d)|[^\r\n\p{L}\p{N}]?\p{L}+|\p{N}| ?[^\s\p{L}\p{N}]+[\r\n]*|\s*[\r\n]+|\s+(?!\S)|\s+"""
enc = tiktoken.Encoding("qwen", pat_str=PAT, mergeable_ranks=load_tiktoken_bpe(str(HERE / "qwen.tiktoken")), special_tokens={})
tok = lambda s: len(enc.encode(s))

SYSTEM = """你是一个在本地代码仓库里工作的编程助手。

# 工作方式
- 先运行测试确认问题，再读相关源码，最后修改。
- 修改用 edit_file，old_str 必须在文件中唯一出现；不唯一时补充上下文后重试。
- 只改让测试通过所必需的代码，不要改测试文件。
- 修改完成后必须重新运行全部测试；测试全部通过才能结束。

# 环境
- 工作目录：/workspace/ledger-cli
- Python 3.12，已安装 pytest"""

TOOLS = [
    {"type": "function", "function": {
        "name": "bash",
        "description": "在工作目录执行一条 shell 命令，返回退出码和输出（超过 8000 字符截断）。用于运行测试、查看目录。",
        "parameters": {"type": "object", "properties": {
            "command": {"type": "string", "description": "要执行的命令"}},
            "required": ["command"]}}},
    {"type": "function", "function": {
        "name": "read_file",
        "description": "读取文本文件，返回带行号的内容。",
        "parameters": {"type": "object", "properties": {
            "path": {"type": "string", "description": "相对工作目录的路径"}},
            "required": ["path"]}}},
    {"type": "function", "function": {
        "name": "edit_file",
        "description": "把文件中的 old_str 替换为 new_str。old_str 必须与文件内容逐字一致且只出现一次。",
        "parameters": {"type": "object", "properties": {
            "path": {"type": "string"},
            "old_str": {"type": "string", "description": "要替换的原文，需唯一"},
            "new_str": {"type": "string", "description": "替换后的内容"}},
            "required": ["path", "old_str", "new_str"]}}},
]

USER = "tests 里有几个用例挂了，帮我修好，让 pytest 全部通过。"


def run_tool(name, args):
    if name == "bash":
        p = subprocess.run(args["command"], shell=True, cwd=WORK, capture_output=True, text=True, timeout=60)
        out = (p.stdout + p.stderr)
        if len(out) > 8000:
            out = out[:8000] + f"\n...[已截断，共 {len(out)} 字符]"
        return f"exit_code={p.returncode}\n{out}", True
    if name == "read_file":
        f = WORK / args["path"]
        lines = f.read_text(encoding="utf-8").splitlines()
        return "\n".join(f"{i+1:>4}  {l}" for i, l in enumerate(lines)), True
    if name == "edit_file":
        f = WORK / args["path"]
        s = f.read_text(encoding="utf-8")
        n = s.count(args["old_str"])
        if n == 0:
            return f"错误：old_str 在 {args['path']} 中没有找到。请先 read_file 确认原文。", False
        if n > 1:
            return (f"错误：old_str 在 {args['path']} 中出现了 {n} 次，无法确定替换哪一处。"
                    "请在 old_str 中加入更多上下文，使其唯一。"), False
        f.write_text(s.replace(args["old_str"], args["new_str"]), encoding="utf-8")
        return f"已修改 {args['path']}（替换 1 处）", True
    raise ValueError(name)


# ---- 模型侧输出（设计稿） ----
TURNS = [
    {"content": None, "calls": [("bash", {"command": "python -m pytest -q"})]},
    {"content": "4 个用例失败，分别落在 parser、money、report 三个模块。先看这三个文件。",
     "calls": [("read_file", {"path": "src/ledger/parser.py"}),
               ("read_file", {"path": "src/ledger/money.py"}),
               ("read_file", {"path": "src/ledger/report.py"})]},
    {"content": "原因找到了：\n1. parse_amount 不认千分位逗号；\n2. round_money 先转 float 再 round，2.675 在二进制里略小于 2.675，舍成了 2.67；\n3. monthly_totals 的 key 只有月份，2025-12 和 2026-12 被合到一起。\n先改 parser。",
     "calls": [("edit_file", {"path": "src/ledger/parser.py",
                              "old_str": "        return Decimal(text)",
                              "new_str": "        return Decimal(text.replace(\",\", \"\"))"})]},
    {"content": "parser.py 里 parse_budget 也有同样一行，带上下面的报错信息让它唯一。money 和 report 一起改。",
     "calls": [("edit_file", {"path": "src/ledger/parser.py",
                              "old_str": "        return Decimal(text)\n    except InvalidOperation as e:\n        raise ParseError(f\"金额格式错误",
                              "new_str": "        return Decimal(text.replace(\",\", \"\"))\n    except InvalidOperation as e:\n        raise ParseError(f\"金额格式错误"}),
               ("edit_file", {"path": "src/ledger/money.py",
                              "old_str": "from decimal import Decimal\n\n\ndef round_money(value) -> Decimal:\n    \"\"\"四舍五入到分。\"\"\"\n    return Decimal(str(round(float(value), 2)))",
                              "new_str": "from decimal import ROUND_HALF_UP, Decimal\n\n\ndef round_money(value) -> Decimal:\n    \"\"\"四舍五入到分。\"\"\"\n    return Decimal(str(value)).quantize(Decimal(\"0.01\"), rounding=ROUND_HALF_UP)"}),
               ("edit_file", {"path": "src/ledger/report.py",
                              "old_str": "key = f\"{e.day.month:02d}\"",
                              "new_str": "key = f\"{e.day.year}-{e.day.month:02d}\""})]},
    {"content": None, "calls": [("bash", {"command": "python -m pytest -q"})]},
    {"content": "27 个用例全部通过。改了三处：\n- parser.py：parse_amount 解析前去掉千分位逗号；\n- money.py：round_money 改用 Decimal 的 ROUND_HALF_UP，不再经过 float；\n- report.py：按月汇总的 key 加上年份，跨年的同月份不再合并。\n测试文件没有改动。",
     "calls": []},
]

messages = [{"role": "system", "content": SYSTEM}, {"role": "user", "content": USER}]
tools_json = json.dumps(TOOLS, ensure_ascii=False)
trace = []
cid = 0
for i, t in enumerate(TURNS, 1):
    req_text = tools_json + json.dumps(messages, ensure_ascii=False)
    in_tok = tok(req_text)
    msg = {"role": "assistant", "content": t["content"]}
    tcs = []
    for name, args in t["calls"]:
        cid += 1
        tcs.append({"id": f"call_{cid:02d}", "type": "function",
                    "function": {"name": name, "arguments": json.dumps(args, ensure_ascii=False)}})
    if tcs:
        msg["tool_calls"] = tcs
    out_tok = tok(json.dumps(msg, ensure_ascii=False))
    finish = "tool_calls" if tcs else "stop"
    messages.append(msg)
    results = []
    for tc in tcs:
        args = json.loads(tc["function"]["arguments"])
        res, ok = run_tool(tc["function"]["name"], args)
        messages.append({"role": "tool", "tool_call_id": tc["id"], "content": res})
        results.append({"id": tc["id"], "name": tc["function"]["name"], "ok": ok,
                        "chars": len(res), "tokens": tok(res), "preview": res[:300]})
    trace.append({"request": i, "input_tokens": in_tok, "output_tokens": out_tok,
                  "finish_reason": finish, "assistant": msg, "tool_results": results})

json.dump({"system": SYSTEM, "tools": TOOLS, "user": USER, "messages": messages, "trace": trace},
          open(HERE / "trace_full.json", "w"), ensure_ascii=False, indent=2)

sys_tok = tok(SYSTEM); tools_tok = tok(tools_json)
print(f"system={sys_tok} tools={tools_tok} user={tok(USER)}")
tot_in = tot_out = 0
for r in trace:
    tot_in += r["input_tokens"]; tot_out += r["output_tokens"]
    calls = ", ".join(f"{x['name']}({'ok' if x['ok'] else 'ERR'},{x['tokens']}t)" for x in r["tool_results"])
    print(f"#{r['request']} in={r['input_tokens']:>5} out={r['output_tokens']:>4} {r['finish_reason']:<10} {calls}")
print("total in", tot_in, "out", tot_out, "ratio", round(tot_in / tot_out, 1))
tool_tok = sum(x["tokens"] for r in trace for x in r["tool_results"])
print("tool result tokens total", tool_tok)
last_in = trace[-1]["input_tokens"]
print("final request breakdown: sys+tools", sys_tok + tools_tok, "tool results", tool_tok)
