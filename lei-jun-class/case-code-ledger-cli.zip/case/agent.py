"""贯穿案例用的最小 Agent。第一部分讲义里的代码片段都出自这个文件。

用法：
    python agent.py              # 用回放模型跑（不需要 API key，复现标准 trace）
    MODEL_NAME=xxx OPENAI_BASE_URL=... OPENAI_API_KEY=... python agent.py --live
"""
import hashlib, json, os, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

WORKDIR = Path(os.environ.get("WORKDIR", "./_run"))
MAX_STEPS = 30            # 最多调多少次模型
MAX_TOKENS_BUDGET = 200_000  # 整个任务累计输入 token 上限
READ_ONLY = {"read_file"}    # 可以并发执行的工具
NEED_APPROVAL = ("rm ", "git push", "git reset")  # bash 里这些前缀要人确认


# ---------- 工具实现 ----------
def bash(command: str) -> str:
    p = subprocess.run(command, shell=True, cwd=WORKDIR, capture_output=True, text=True, timeout=120)
    out = p.stdout + p.stderr
    if len(out) > 8000:
        out = out[:8000] + f"\n...[已截断，共 {len(out)} 字符]"
    return f"exit_code={p.returncode}\n{out}"


def read_file(path: str) -> str:
    lines = (WORKDIR / path).read_text(encoding="utf-8").splitlines()
    return "\n".join(f"{i + 1:>4}  {l}" for i, l in enumerate(lines))


class ToolError(Exception):
    """工具层错误：原因要回填给模型，让它自己改。"""


def edit_file(path: str, old_str: str, new_str: str) -> str:
    f = WORKDIR / path
    s = f.read_text(encoding="utf-8")
    n = s.count(old_str)
    if n == 0:
        raise ToolError(f"old_str 在 {path} 中没有找到。请先 read_file 确认原文。")
    if n > 1:
        raise ToolError(f"old_str 在 {path} 中出现了 {n} 次，无法确定替换哪一处。请在 old_str 中加入更多上下文，使其唯一。")
    f.write_text(s.replace(old_str, new_str), encoding="utf-8")
    return f"已修改 {path}（替换 1 处）"


TOOL_IMPLS = {"bash": bash, "read_file": read_file, "edit_file": edit_file}


# ---------- 执行一次工具调用 ----------
def run_one(tc, approve) -> dict:
    name = tc.function.name
    try:
        args = json.loads(tc.function.arguments)              # 1 解析
    except json.JSONDecodeError as e:
        return tool_msg(tc.id, f"错误：参数不是合法 JSON：{e}")
    if name not in TOOL_IMPLS:                                 # 2 校验
        return tool_msg(tc.id, f"错误：没有名为 {name} 的工具")
    if name == "bash" and args.get("command", "").startswith(NEED_APPROVAL):
        if not approve(name, args):                            # 3 权限
            return tool_msg(tc.id, "用户拒绝执行该命令。请换一种不需要该操作的做法。")
    try:
        result = TOOL_IMPLS[name](**args)                      # 4 执行
    except ToolError as e:
        result = f"错误：{e}"
    except subprocess.TimeoutExpired:
        result = "错误：命令超时（120 秒）"
    except Exception as e:                                     # 兜底：文件不存在、参数缺失等
        result = f"错误：{type(e).__name__}: {e}"
    return tool_msg(tc.id, result)                             # 5 截断已在工具内做 6 回填


def tool_msg(call_id, content):
    return {"role": "tool", "tool_call_id": call_id, "content": content}


def run_tools(tool_calls, approve) -> list[dict]:
    """只读的并发跑，写操作按顺序跑；结果按原顺序回填。"""
    results = {}
    reads = [tc for tc in tool_calls if tc.function.name in READ_ONLY]
    with ThreadPoolExecutor() as pool:
        for tc, r in zip(reads, pool.map(lambda t: run_one(t, approve), reads)):
            results[tc.id] = r
    for tc in tool_calls:
        if tc.id not in results:
            results[tc.id] = run_one(tc, approve)
    return [results[tc.id] for tc in tool_calls]


# ---------- 调模型：API 层错误在这里自己扛 ----------
def call_model(client, model, messages, tools):
    for attempt in range(4):
        try:
            return client.chat.completions.create(model=model, messages=messages, tools=tools)
        except Exception as e:  # 429 / 5xx / 超时
            if attempt == 3:
                raise
            time.sleep(2 ** attempt)


# ---------- 完成校验：模型说完成了，Runtime 自己再跑一遍测试 ----------
def tests_pass() -> bool:
    p = subprocess.run("python -m pytest -q", shell=True, cwd=WORKDIR, capture_output=True, timeout=300)
    return p.returncode == 0


# ---------- 主循环 ----------
def agent_loop(client, model, system, tools, user_input, approve=lambda n, a: True,
               verify=tests_pass, log=print):
    messages = [{"role": "system", "content": system}, {"role": "user", "content": user_input}]
    seen, reminded, used = {}, set(), 0
    for step in range(1, MAX_STEPS + 1):
        resp = call_model(client, model, messages, tools)
        choice, used = resp.choices[0], used + resp.usage.prompt_tokens
        msg = choice.message
        log(f"#{step} finish_reason={choice.finish_reason} in={resp.usage.prompt_tokens} out={resp.usage.completion_tokens}")

        if choice.finish_reason == "length":                     # 截断：半截的 tool_calls 不能放回
            messages.append({"role": "assistant", "content": msg.content or ""})
            messages.append({"role": "user", "content": "输出被截断了，请重新给出完整的工具调用。"})
            continue
        messages.append(assistant_msg(msg))                      # 放回

        if choice.finish_reason == "stop":                       # 判断
            if verify is None or verify():                       # 完成校验
                return msg.content, messages
            messages.append({"role": "user", "content": "测试还没有全部通过，请继续修复。"})
            continue
        if choice.finish_reason == "content_filter":
            return "请求被内容安全策略拦截。", messages

        for tc in msg.tool_calls or []:                          # 循环检测
            h = hashlib.md5((tc.function.name + tc.function.arguments).encode()).hexdigest()
            seen[h] = seen.get(h, 0) + 1
            if seen[h] >= 4:                                     # 停之前也要给每个调用补结果
                messages.extend(tool_msg(t.id, "已停止：重复调用") for t in msg.tool_calls)
                return f"同一个调用重复了 {seen[h]} 次，已停止。", messages
        messages.extend(run_tools(msg.tool_calls, approve))      # 执行 + 回填
        for h, n in seen.items():
            if n == 3 and h not in reminded:
                reminded.add(h)
                messages.append({"role": "user", "content": "你已经用相同参数调用了 3 次，换个思路。"})
        if used > MAX_TOKENS_BUDGET:                              # 预算
            return "token 预算用完，任务未完成。", messages
    return f"达到最大步数 {MAX_STEPS}，任务未完成。", messages


def assistant_msg(msg):
    m = {"role": "assistant", "content": msg.content}
    if msg.tool_calls:
        m["tool_calls"] = [{"id": t.id, "type": "function",
                            "function": {"name": t.function.name, "arguments": t.function.arguments}}
                           for t in msg.tool_calls]
    return m


# ---------- 回放模型：按标准 trace 返回，便于离线演示 ----------
class ReplayClient:
    def __init__(self, trace_path):
        from types import SimpleNamespace as NS
        data = json.load(open(trace_path, encoding="utf-8"))
        self._turns = iter(data["trace"])
        self._NS = NS
        self.chat = NS(completions=NS(create=self._create))

    def _create(self, model, messages, tools):
        NS = self._NS
        t = next(self._turns)
        a = t["assistant"]
        tcs = [NS(id=x["id"], function=NS(name=x["function"]["name"], arguments=x["function"]["arguments"]))
               for x in a.get("tool_calls", [])] or None
        return NS(choices=[NS(message=NS(content=a["content"], tool_calls=tcs), finish_reason=t["finish_reason"])],
                  usage=NS(prompt_tokens=t["input_tokens"], completion_tokens=t["output_tokens"]))


if __name__ == "__main__":
    here = Path(__file__).parent
    data = json.load(open(here / "trace_full.json", encoding="utf-8"))
    if "--live" in sys.argv:
        from openai import OpenAI
        client, model = OpenAI(), os.environ["MODEL_NAME"]
    else:
        client, model = ReplayClient(here / "trace_full.json"), "replay"
    answer, msgs = agent_loop(client, model, data["system"], data["tools"], data["user"])
    print("\n" + answer)
    json.dump(msgs, open(here / "run_messages.json", "w"), ensure_ascii=False, indent=2)
